import 'package:flutter/material.dart';
import 'package:ajin2/bottomnavigationbar.dart';
import 'package:ajin2/ui/top_category.dart';

class MyAccordion extends StatefulWidget {
  const MyAccordion({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyAccordion> createState() => _MyAccordionState();
}

class _MyAccordionState extends State<MyAccordion> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [IconButton(icon: Icon(Icons.settings, color: Colors.white,), onPressed: null)],
        elevation: 1,
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: const Text("Ajin's Diary"),
              accountEmail: const Text('ajin@test.com'),
              onDetailsPressed: (){},
              currentAccountPicture: const CircleAvatar(
                backgroundImage: AssetImage('/assets/image_animal.jpg'),
                //backgroundColor: Colors.transparent,
              ),
              decoration: BoxDecoration(
                color: Colors.amber[600],
                borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20)
                ),
              ),
              otherAccountsPictures: [
                CircleAvatar(
                  backgroundImage: AssetImage('/assets/image_animal.jpg'),
                  //backgroundColor: Colors.transparent,
                ),
              ],
            ),
/*              Container(
              height: 50,
              padding: EdgeInsets.only(right: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text('Login'),
                  SizedBox(width:5),
                  IconButton(onPressed: null, icon: Icon(Icons.login)),
                ],
              ),
            ),*/
            ListTile(
              leading: const Icon(Icons.schedule, color: Colors.grey),
              title: const Text('Schedule'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/schedule');
              },
              trailing: Icon(Icons.add),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Divider(thickness: 1, height: 1, color: Colors.grey),
            ),
            ListTile(
              leading: const Icon(Icons.contact_phone, color: Colors.grey),
              title: const Text('Contact'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/contact');
              },
              trailing: Icon(Icons.add),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Divider(thickness: 1, height: 1, color: Colors.grey),
            ),
            ListTile(
              leading: const Icon(Icons.menu_book, color: Colors.grey),
              title: const Text('Arcodion Page'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/arcodion');
              },
              trailing: const Icon(Icons.add),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Divider(thickness: 1, height: 1, color: Colors.grey),
            ),
            ListTile(
              leading: Icon(Icons.contact_phone, color: Colors.grey),
              title: Text('Accorodion 예제2'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/xxx');
              },
              trailing: Icon(Icons.add),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Divider(thickness: 1, height: 1, color: Colors.grey),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            TopCategory(firstCtg:'Woman'),
            TopCategory(firstCtg:'Man'),
            TopCategory(firstCtg:'Kids'),
            TopCategory(firstCtg:'Beauty'),
            TopCategory(firstCtg:'Homeware'),
          ],
        ),
      ),
      bottomNavigationBar: const BottomNavi(),
    );
  }
}

class Entry {
  final String title;

  Entry(this.title);
}

// The entire multilevel list displayed by this app.
final List<Entry> data = <Entry>[
  Entry('Chapter A'),
  Entry('Chapter B'),
  Entry('Chapter C'),
]
