import 'package:flutter/material.dart';

class AddContact extends StatefulWidget {
  const AddContact({Key? key, required this.title, this.mode}) : super(key: key);
  final String title ;
  final String? mode;

  @override
  State<AddContact> createState() => _AddContactState();
}

class _AddContactState extends State<AddContact> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        elevation: 1,
      ),
      body: Center(
        child: Text(widget.mode!), //_widgetOptions.elementAt(_selectedIndex),
      ),
    );
  }
}
