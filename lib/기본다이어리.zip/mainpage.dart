import 'package:flutter/material.dart';

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key, required this.title}) : super(key: key);
  final String title;
  //final int index;

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  int _currentIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    if (Uri.base.toString().split('/')[4] == 'schedule') {
      _selectedIndex = 1;
    } else if(Uri.base.toString().split('/')[4] == 'contact') {
      _selectedIndex = 2;
    }
    _currentIndex = _selectedIndex;

    super.initState();
  }
/*  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Schedule',
      style: optionStyle,
    ),
    Text(
      'Index 2: Contact',
      style: optionStyle,
    ),
  ];*/

  void _onItemTapped(int index) {

    print(index);
    setState(() {
      _selectedIndex = index;
    });

    print(Uri.base.toString().contains('/schedule'));

    String routeName='';
    if (index == 0){routeName ='/';}
    else if (index == 1){routeName ='/schedule';}
    else if (index == 2){routeName ='/contact';}

    if (_currentIndex != _selectedIndex) {
      Navigator.pushReplacementNamed(context, '$routeName');
    }
  }

  _bottomNavigaionBar(){
    return BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.schedule),
            label: 'Schedule',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.contact_phone),
            label: 'Contact',
          ),
        ],
        currentIndex: _currentIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        elevation: 1,
      ),
      body: Center(
        child: Text('$_selectedIndex'), //_widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: _bottomNavigaionBar(),
    );
  }
}