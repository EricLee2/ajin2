import 'package:flutter/material.dart';
import 'package:ajin2/addcontact.dart';

class MyContact extends StatefulWidget {
  const MyContact({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyContact> createState() => _MyContactState();
}

class _MyContactState extends State<MyContact> {
  int _selectedIndex = 0;
  int _currentIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    if (Uri.base.toString().split('/')[4] == 'schedule') {
      _selectedIndex = 1;
    } else if(Uri.base.toString().split('/')[4] == 'contact') {
      _selectedIndex = 2;
    }
    _currentIndex = _selectedIndex;

    super.initState();
  }


/*  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Schedule',
      style: optionStyle,
    ),
    Text(
      'Index 2: Contact',
      style: optionStyle,
    ),
  ];*/

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

  //  print(index);
  //  print(Uri.base.toString().split('/')[4]);
    String routeName='';
    if (index == 0){routeName ='/';}
    else if (index == 1){routeName ='/schedule';}
    else if (index == 2){routeName ='/contact';}

    if (_currentIndex != _selectedIndex) {
      Navigator.pushReplacementNamed(context, '$routeName');
    }
  }

  _bottomNavigaionBar(){
    return BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.schedule),
            label: 'Schedule',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.contact_phone),
            label: 'Contact',
          ),
        ],
        currentIndex: _currentIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        elevation: 1,
      ),
      body: Center(
        child: Text('$_selectedIndex'),
      ),
      floatingActionButton: Stack(
        children: <Widget>[
          Align(
            alignment: Alignment.bottomRight,
            child: FloatingActionButton.extended(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>AddContact(title: 'Add contact', mode: 'add mode')));
              },
              label: Text('Add'),
              icon: Icon(Icons.add),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _bottomNavigaionBar(),
    );
  }
}